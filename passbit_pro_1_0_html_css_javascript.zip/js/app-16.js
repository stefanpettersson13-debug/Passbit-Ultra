/* Optional entrance animations. No data mutation or navigation override. */
(()=>{'use strict';
 const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(reduce)return;
 const cards=[...document.querySelectorAll('.dashboard .dashbtn')];
 cards.forEach((card,i)=>card.style.setProperty('--lux-order',String(i)));
 // Mark after style variables are in place; do not animate each navigation item repeatedly.
 document.body.classList.add('lux-ready');
 const sections=[...document.querySelectorAll('section[id]')];
 const observer=new MutationObserver(records=>{
  for(const record of records){
   const el=record.target;
   if(el.classList.contains('hidden'))continue;
   el.classList.remove('lux-section-enter');
   void el.offsetWidth;
   el.classList.add('lux-section-enter');
  }
 });
 sections.forEach(section=>observer.observe(section,{attributes:true,attributeFilter:['class']}));
})();
