(()=>{
'use strict';
const groups={
 workshop:{title:'Verkstadsteknik',tier:'FREE',tools:['holes','screws','sin','convert','cutting','cncpro','workshop10','drawings','electrical']},
 grinding:{title:'Slipteknik',tier:'PRO',tools:['grinding','grindpro','shrink','thermal','diagnostic10']},
 metrology:{title:'Mätteknik',tier:'PRO',tools:['fits','blocks','runout','chain','measure','metrology','alignment','analysis10','reports10','assistant']},
 advanced:{title:'Avancerat',tier:'ULTRA',tools:['abbrobot','sinumerik','pneumatics']},
 projects:{title:'Projekt',tier:'ULTRA',tools:['field','measure','reports10','stock']}
};
const root=document.getElementById('pb-category-root'),grid=document.getElementById('pb-category-grid'),detail=document.getElementById('pb-category-detail'),tools=document.getElementById('pb-category-tools'),homeTitle=document.getElementById('homeTitle');
if(!root)return;
const all=[...document.querySelectorAll('.dashboard .dashbtn[data-go]')];
const used=new Set(Object.values(groups).flatMap(g=>g.tools));
// Do not silently lose tools when the original application grows.
for(const b of all)if(!used.has(b.dataset.go))groups.workshop.tools.push(b.dataset.go);
let current=null;
function reset(){current=null;grid.hidden=false;detail.hidden=true;document.getElementById('pb-project-workspace').hidden=true;tools.hidden=false;homeTitle.textContent='Välj område'}
function open(key){const group=groups[key];if(!group)return;current=key;tools.hidden=key==='projects';document.getElementById('pb-project-workspace').hidden=key!=='projects';grid.hidden=true;detail.hidden=false;homeTitle.textContent='';document.getElementById('pb-category-title').textContent=group.title;document.getElementById('pb-category-tier').textContent=group.tier;tools.replaceChildren();
 for(const id of group.tools){const original=all.find(x=>x.dataset.go===id);if(!original)continue;const b=document.createElement('button');b.type='button';b.className='pb-category-tool';const icon=document.createElement('span');icon.className='pb-tool-icon';icon.textContent=original.querySelector('.glyph')?.textContent.trim()||'◇';const label=document.createElement('span');label.textContent=original.querySelector('strong')?.textContent||id;b.append(icon,label);b.addEventListener('click',()=>original.click());tools.append(b)}
 if(key==='projects'){window.passbitProjectsRender?.();}
}
root.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>open(b.dataset.category)));
document.getElementById('pb-category-back').addEventListener('click',reset);
// Home button is managed by existing application; restore category overview on next home visit.
const observer=new MutationObserver(()=>{if(document.body.classList.contains('home-view')&&!grid.hidden&&current)reset()});
observer.observe(document.body,{attributes:true,attributeFilter:['class']});
// Also reset when the existing Home control is explicitly pressed.
document.getElementById('homeButton')?.addEventListener('click',()=>{if(!document.body.classList.contains('home-view'))return;reset()});
})();