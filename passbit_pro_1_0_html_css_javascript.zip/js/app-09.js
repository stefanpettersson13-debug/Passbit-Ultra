
/* Press for 550ms, then drag cards. Compatible with Safari touch events and mouse. */
(()=>{
const dash=document.querySelector('.dashboard');if(!dash)return;
const KEY='passbit-menu-order-v63';
const hint=document.createElement('p');hint.className='pb67-sort-hint';hint.textContent='Håll ned ett verktyg för att flytta det';dash.insertAdjacentElement('afterend',hint);
let pending=null,active=null,ghost=null,timer=null,blockClick=false,blockTimer=null;
const card=el=>el?.closest?.('.dashbtn[data-go]');
function save(){try{localStorage.setItem(KEY,JSON.stringify([...dash.querySelectorAll('.dashbtn[data-go]')].map(el=>el.dataset.go)))}catch{}}
function clearTimer(){if(timer){clearTimeout(timer);timer=null}}
function start(b,x,y){if(!pending||pending.el!==b)return;active={el:b,dx:x-pending.rect.left,dy:y-pending.rect.top};ghost=b.cloneNode(true);ghost.classList.add('pb67-drag-ghost');ghost.style.width=pending.rect.width+'px';ghost.style.height=pending.rect.height+'px';document.body.append(ghost);b.classList.add('pb67-dragging');document.body.classList.add('pb67-sorting');position(x,y);if(navigator.vibrate)try{navigator.vibrate(20)}catch{};hint.textContent='Dra till önskad plats och släpp';}
function position(x,y){if(!active||!ghost)return;ghost.style.left=(x-active.dx)+'px';ghost.style.top=(y-active.dy)+'px';const hit=card(document.elementFromPoint(x,y));if(hit&&hit!==active.el&&dash.contains(hit)){const cards=[...dash.querySelectorAll('.dashbtn[data-go]')],i=cards.indexOf(active.el),j=cards.indexOf(hit);if(i<j)dash.insertBefore(active.el,hit.nextSibling);else dash.insertBefore(active.el,hit);}}
function end(){clearTimer();pending=null;if(active){active.el.classList.remove('pb67-dragging');ghost?.remove();ghost=null;active=null;document.body.classList.remove('pb67-sorting');save();hint.textContent='Håll ned ett verktyg för att flytta det';blockClick=true;clearTimeout(blockTimer);blockTimer=setTimeout(()=>blockClick=false,450)}}
dash.addEventListener('click',e=>{if(blockClick){e.preventDefault();e.stopImmediatePropagation();blockClick=false;}},true);
dash.addEventListener('contextmenu',e=>{if(active||pending){e.preventDefault()}},true);
// Native touch handlers allow normal scrolling unless the long press has activated.
dash.addEventListener('touchstart',e=>{if(e.touches.length!==1||active)return;const t=e.touches[0],b=card(e.target);if(!b)return;clearTimer();const rect=b.getBoundingClientRect();pending={el:b,x:t.clientX,y:t.clientY,rect};timer=setTimeout(()=>{timer=null;start(b,t.clientX,t.clientY)},550)},{passive:true});
dash.addEventListener('touchmove',e=>{if(!pending&&!active)return;const t=e.touches[0];if(!t)return;if(active){e.preventDefault();position(t.clientX,t.clientY)}else if(Math.hypot(t.clientX-pending.x,t.clientY-pending.y)>9){clearTimer();pending=null}},{passive:false});
dash.addEventListener('touchend',()=>end(),{passive:true});dash.addEventListener('touchcancel',()=>end(),{passive:true});
// Desktop: long press with mouse, then drag.
dash.addEventListener('mousedown',e=>{if(e.button!==0||active)return;const b=card(e.target);if(!b)return;clearTimer();const rect=b.getBoundingClientRect();pending={el:b,x:e.clientX,y:e.clientY,rect};timer=setTimeout(()=>{timer=null;start(b,pending.x,pending.y)},550)});
window.addEventListener('mousemove',e=>{if(active){position(e.clientX,e.clientY)}else if(pending&&Math.hypot(e.clientX-pending.x,e.clientY-pending.y)>9){clearTimer();pending=null}});
window.addEventListener('mouseup',()=>end());window.addEventListener('blur',()=>end());
})();
